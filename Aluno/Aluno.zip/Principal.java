public class Principal {
    public static void main(String args[]){
        Aluno Ana = new Aluno("Ana Maria da Silva",18,'F',0,true,8.3);
        Professor Jose = new Professor("Jose de Alencar Bastos",43,'M',2,true,"Analise de Dados",60);
        Funcionario Milton = new Funcionario("Milton Nascimento dos Santos",57,'M',0,false,"Zelador");

        System.out.println("\tAlunos:");
        System.out.println(Ana.getNome());
        System.out.println(Ana.getIdade()+" anos");
        System.out.print("Sexo: ");
        Ana.setSexo(Ana.getSexo());
        System.out.println("Quantidade de Faltas: "+Ana.getFaltas());
        System.out.print("Cadastro: ");
        Ana.setAtivo(Ana.getAtivo());
        System.out.println("Média: "+Ana.getMedia());

        System.out.println("\n\n");

        System.out.println("\tProfessores:");
        System.out.println(Jose.getNome());
        System.out.println(Jose.getIdade()+" anos");
        System.out.print("Sexo: ");
        Jose.setSexo(Jose.getSexo());
        System.out.println("Quantidade de Faltas: "+Jose.getFaltas());
        System.out.print("Cadastro: ");
        Jose.setAtivo(Jose.getAtivo());
        System.out.println("Materia lecionada: "+Jose.getMateria());
        System.out.println("Quantidade de horas aula: "+Jose.getHoraAula());

        System.out.println("\n\n");

        System.out.println("\tFuncionarios:");
        System.out.println(Milton.getNome());
        System.out.println(Milton.getIdade()+" anos");
        System.out.print("Sexo: ");
        Milton.setSexo(Milton.getSexo());
        System.out.println("Quantidade de Faltas: "+Milton.getFaltas());
        System.out.print("Cadastro: ");
        Milton.setAtivo(Milton.getAtivo());
        System.out.println("Cargo: "+Milton.getCargo());


    }
}
